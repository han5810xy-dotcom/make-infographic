# 对话 → 知识结构：作者流程

默认产物不再是“文字直接变像素”。必须先交出 Proposition／Relation／Structure，程序校验通过后才能建 View 和渲染。

## 1. 完整归档

把用户选中的对话完整存成 `<工作目录>/.source.md`。保留发言者、轮次、标点、代码和原始措辞；不要先概括，不要补写原文没有的内容。

## 2. 完整通读

先数清用户轮次和助手轮次，再通读全文。标出开场定义、用户旧判断、反例、纠正、结论位、追问和例外。不要只看金句。

## 3. 逐条命题化

每条命题只放一件事，写成“谁，关于什么，断言了什么”，可见字数不超过 60。

- `kind` 只能是：定义、主张、因果、条件、对比、步骤、例子、例外、数据。
- 每条命题附 1~2 条 `evidence`。作者稿写 `{speaker, turn_index, text, verbatim:true}`，程序会把 `text` 解析成稳定 `quote_id`。
- `text` 必须是对应发言者那一轮里的连续原句；程序按 `kind + 规范化 text` 生成跨对话稳定的 `concept_id`。
- 可选 `probe_questions` 为 `recall/explain/apply/transfer` 写不含答案的题干；缺省时由程序生成。
- 命题文字是原文逐字片段才标 `provenance: "quote"`；压缩或改写后标 `"summary"`。
- 没有证据的命题不要写进 `propositions`，把它写进 `gaps`。
- 删除寒暄、重复、免责声明、进度描述、代码／配置碎片和中间推理；同一事实只留信息量最大的那条。
- 命题超过 30 条说明有多个主题，拆成多个 Structure，不要硬塞。

## 4. 先写关键结论

在作者稿里另写 `key_conclusions`：3~5 条逐字原句，覆盖这段对话最主要的结论。漏掉的结论会尽量补成有证据的命题；无法在单条命题上限内完整表达时，明确写入缺口并在覆盖报告中降级。

## 5. 解析与校验

作者稿示例：

```json
{
  "topic": "分数与理解",
  "propositions": [
    {
      "id": "p1",
      "kind": "主张",
      "text": "分数高说明学习有效",
      "evidence": [{ "speaker": "user", "turn_index": 0, "text": "我以为分数高就说明学习有效。", "verbatim": true }],
      "provenance": "quote"
    }
  ],
  "gaps": [],
  "key_conclusions": ["我以为分数高就说明学习有效。"]
}
```

用 `knowledge-authoring.mjs` 解析证据，用 `knowledge-contract.mjs` 校验。没有通过证据校验的结构不能进入关系层，更不能出图。

## 6. 覆盖自查

逐条对照 `key_conclusions`：每条关键结论至少要落到一条命题或它的 evidence 上。漏掉的关键结论超过 10%，回到第 3 步补命题，不要靠画图时补字。

M1 只交付结构、证据、缺口和覆盖报告；M2 才允许建关系，M4 才允许渲染。
