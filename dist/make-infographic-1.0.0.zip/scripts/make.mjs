import { readFile, mkdir, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve, basename } from 'node:path';
import { startCli, workdir, opt, wantsHelp, checkFlags, WORKDIR_HELP, WORKDIR_FLAGS } from './console.mjs';
import { writeAtomic, sha } from './safeio.mjs';
import { reserveArtifact, withArtifactLock } from './artifacts.mjs';
import { buildTurnHtml, renderTurnPng, esc } from './render.mjs';
import { TURN_LAYOUT, TURN_LIMIT, extractTurn, normalizeTurnCard, demoCard, printOmissions, turnBodyChars, visibleLen, DEMO_SOURCE } from './turn-card.mjs';

let WS = process.cwd();
const outDir = () => join(WS, 'infographics');
const p2 = (n) => String(n).padStart(2, '0');
const now = (d = new Date()) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`;
const fileStamp = (d = new Date()) => `${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}`;
const slug = (s) => String(s).replace(/[\\/:*?"<>|\s，。：；、！？]+/g, '').slice(0, 24) || '转弯图';
const FLAGS = ['spec', 'in', 'source', 'template', 'out', 'scale', 'demo', 'html-only', 'help', ...WORKDIR_FLAGS];

export function extractJson(raw) {
  const text = String(raw).trim();
  try { return JSON.parse(text); } catch {}
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) return JSON.parse(fenced[1]);
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start >= 0 && end > start) return JSON.parse(text.slice(start, end + 1));
  throw new Error('这个文件里没有可读的 JSON。');
}

function outBase(argv, fallback) {
  const arg = opt(argv, 'out', '');
  if (!arg) return fallback;
  const name = basename(arg).replace(/\.png$/i, '');
  if (name !== arg) console.log(`注意：--out 只取名字部分（${name}），产物仍写入 ${outDir()}。`);
  return slug(name);
}

async function readSource(path) {
  try { return await readFile(resolve(path), 'utf8'); }
  catch { throw new Error(`读不到内容文件：${resolve(path)}\n  --in 需要指向一段 .md 或 .txt 内容。`); }
}

export async function refreshIndex(ws = WS) {
  if (!ws) throw new Error('刷新图集需要工作目录。');
  return withArtifactLock(ws, async () => {
    const dir = join(ws, 'infographics');
    let names = [];
    try { names = await readdir(dir); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    const cards = [];
    for (const name of names.filter((n) => n.endsWith('.json')).sort()) {
      let data;
      try { data = JSON.parse(await readFile(join(dir, name), 'utf8')); } catch { continue; }
      if (data.layout !== TURN_LAYOUT) continue;
      const stem = basename(name, '.json');
      cards.push({ stem, data, png: names.includes(`${stem}.png`) ? `${stem}.png` : '', html: names.includes(`${stem}.html`) ? `${stem}.html` : '' });
    }
    cards.sort((a, b) => String(b.data.createdAt || '').localeCompare(String(a.data.createdAt || '')));
    const items = cards.map(({ stem, data, png, html }) => `<article class="card"><a href="${png || html}">${png ? `<img src="${png}" alt="${esc(data.title)}" loading="lazy">` : '<span>HTML</span>'}</a><h2>${esc(data.title)}</h2><p>${esc(data.createdAt || '')} · 正文 ${data.bodyChars || turnBodyChars(data)} 字${data.demo ? ' · 示例' : ''}</p><p><a href="${stem}.json">内容记录</a> · <a href="${stem}.source.md">原文</a></p></article>`).join('');
    const page = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>转弯图集</title><style>*{box-sizing:border-box}body{margin:0;background:#f5f7fc;color:#17181c;font-family:"Microsoft YaHei","PingFang SC",sans-serif}main{max-width:1120px;margin:auto;padding:48px 24px}h1{font-size:36px}p{color:#5c626e}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:22px}.card{background:#fff;border:1px solid #dce2ee;border-radius:14px;padding:16px}.card img{width:100%;height:auto;display:block;border-radius:8px}.card h2{font-size:20px;margin:16px 0 8px}.card p{font-size:14px;margin:6px 0}.card a{color:#2f5cff}@media(max-width:760px){.grid{grid-template-columns:1fr}}</style></head><body><main><h1>转弯图集</h1><p>一张图，只记录一次判断改变。</p><div class="grid">${items || '<p>还没有图。</p>'}</div></main></body></html>`;
    await writeAtomic(join(dir, 'index.html'), page);
    return { page: join(dir, 'index.html'), count: cards.length };
  });
}

export async function main(argv = process.argv.slice(2), opts = {}) {
  checkFlags(argv, FLAGS);
  WS = workdir(argv);
  const inVal = opt(argv, 'in', '');
  const specFile = opt(argv, 'spec', '');
  const demo = argv.includes('--demo');
  if (wantsHelp(argv) || (!specFile && !demo && !inVal)) {
    console.log(`用法：node scripts/make.mjs --in 内容.md [--out 名字]\n     node scripts/make.mjs --spec 转弯图.json [--in 原文.md]\n     node scripts/make.mjs --demo\n\n默认只出一种竖图：原以为 → 撞车 → 正解 → 一句带走。\n不需要 API key。正文最多 ${TURN_LIMIT} 字；超限自动删减并打印「未上图」。\n可选：--out 名字  --scale 2  --html-only  --template 旧版式名（会自动换成转弯图）\n　　${WORKDIR_HELP}\n产物：<工作目录>/infographics/ 下的 PNG、HTML、完整 JSON 与归档原文。`);
    return 0;
  }
  const scale = Number(opt(argv, 'scale', '2'));
  if (!Number.isFinite(scale) || scale <= 0) throw new Error('--scale 需要是正数。');
  const template = opt(argv, 'template', '');
  let input = null;
  let source = '';
  let sourceFile = '';
  if (specFile) {
    try { input = extractJson(await readFile(resolve(specFile), 'utf8')); }
    catch (e) { throw new Error(`读不到图规格：${resolve(specFile)}\n  ${e.message}`); }
    const src = opt(argv, 'source', '') || inVal;
    if (src) { source = await readSource(src); sourceFile = resolve(src); }
  } else if (demo) {
    const d = demoCard();
    input = d.card;
    source = DEMO_SOURCE;
    sourceFile = '内置示例';
    console.log('这次使用内置示例（--demo），不是你的对话。');
  } else {
    source = await readSource(inVal);
    sourceFile = resolve(inVal);
  }
  if (visibleLen(source) > 30000) throw new Error('这段内容超过 30000 字。请先选出包含一次完整转弯的片段。');
  if (!source && !input) throw new Error('没有读到内容，不能出图。');
  const oldShape = input && (input.template || input.form || input.layout) && (input.template || input.form || input.layout) !== TURN_LAYOUT;
  if (template || oldShape) console.log('内容不是旧的固定版式，已自动换成四块转弯图。');
  const result = source ? normalizeTurnCard(input || extractTurn(source), { source, demo }) : normalizeTurnCard(input, { demo });
  const { card, omitted, origins, memory } = result;
  console.log(`出图前自检：一年后只看到这张图，能想起这次对话吗？→ ${memory.reason}`);
  if (!memory.ok) throw new Error(`没出图：${memory.reason}`);
  const paraphrased = Object.entries(origins).filter(([, v]) => v === '归纳').map(([k]) => k);
  if (paraphrased.length) console.log(`有 ${paraphrased.length} 块不是逐字原话，已按归纳写进内容记录；画面不显示这个标记。`);
  if (omitted.length) {
    printOmissions(omitted);
    console.log(`已自动裁剪到 ${turnBodyChars(card)} 字，没有缩小字号。`);
  }
  await mkdir(outDir(), { recursive: true });
  const createdAt = now();
  const base = outBase(argv, `${fileStamp()}_${slug(card.title)}`);
  const payload = { ...card, createdAt, sourceFile, sourceChars: visibleLen(source), bodyChars: turnBodyChars(card), origins, omitted, memory };
  const tx = await reserveArtifact({ workspace: WS, base, fingerprint: sha(JSON.stringify(payload)) });
  if (tx.note) console.log(tx.note);
  try {
    let qa = null;
    await tx.add(`${tx.stem}.html`, buildTurnHtml(card), { media: 'html' });
    if (argv.includes('--html-only')) {
      console.log(`HTML 已生成：${join(outDir(), `${tx.stem}.html`)}（未截图，未做浏览器实测）`);
    } else {
      const staged = tx.path(`${tx.stem}.png`);
      const rendered = await renderTurnPng(card, staged, { scale });
      qa = rendered.qa;
      await tx.add(`${tx.stem}.png`, await readFile(staged), { kind: 'binary', media: 'png', widthPx: rendered.widthPx, heightPx: rendered.heightPx });
      console.log(`PNG 已生成：${join(outDir(), `${tx.stem}.png`)}  (${rendered.widthPx}x${rendered.heightPx})`);
      console.log(`画面检查：正文 ${qa.metrics.bodyChars} 字；1080 稿正文 ${qa.metrics.bodyFontPx.join('/')}px；600px 宽约 ${qa.metrics.fontAt600Px.join('/')}px。`);
    }
    payload.qa = qa;
    await tx.add(`${tx.stem}.json`, JSON.stringify(payload, null, 2), { media: 'json' });
    if (source) await tx.add(`${tx.stem}.source.md`, source, { media: 'source' });
    const published = await tx.commit();
    console.log(`内容记录：${join(outDir(), `${tx.stem}.json`)}`);
    if (source) console.log(`归档原文：${join(outDir(), `${tx.stem}.source.md`)}`);
    const idx = await refreshIndex(WS);
    console.log(`图集已更新：${idx.page}`);
    console.log('OK');
    return 0;
  } catch (e) {
    await tx.abort(String(e.message || e));
    throw e;
  }
}

startCli(import.meta.url, 'make', main);
