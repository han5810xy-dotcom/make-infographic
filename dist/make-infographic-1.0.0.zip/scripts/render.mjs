import { launchBrowser, closeBrowser } from './browser.mjs';
import { TURN_LABELS, turnBodyChars } from './turn-card.mjs';

export const WIDTH = 1080;
export const HEIGHT = 1560;
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export function buildTurnHtml(card, { height = HEIGHT } = {}) {
  const block = (key) => {
    const label = TURN_LABELS[key];
    return `<section class="turn-block ${key}" data-turn-block="${key}"><div class="turn-label">${label}</div><div class="turn-text" data-body-text="${key}">${esc(card[key])}</div></section>`;
  };
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><style>
  :root{--ink:#17181c;--muted:#5c626e;--brand:#2f5cff;--line:#dce2ee;--paper:#fff;--wash:#f5f7fc;--warn:#a86400;--warn-bg:#fff7e9}
  *{box-sizing:border-box;margin:0;padding:0}html,body{background:#fff}body{font-family:"Microsoft YaHei","PingFang SC","Noto Sans SC","Source Han Sans SC",sans-serif;color:var(--ink);-webkit-font-smoothing:antialiased}
  #canvas{width:${WIDTH}px;height:${height}px;padding:60px 64px;background:var(--paper);display:flex;flex-direction:column;overflow:hidden}
  h1{font-size:54px;line-height:1.22;font-weight:800;letter-spacing:-.5px;overflow-wrap:anywhere;flex:0 0 auto;max-height:140px}
  .turn-body{display:grid;grid-template-rows:1fr 1fr 1fr 1.08fr;gap:22px;margin-top:34px;flex:1;min-height:0}
  .turn-block{border:1px solid var(--line);border-left:8px solid #aab3c3;border-radius:16px;padding:26px 32px;background:var(--wash);min-height:0;overflow:hidden}
  .turn-label{font-size:24px;line-height:1.2;font-weight:800;letter-spacing:2px;color:var(--muted);margin-bottom:14px}
  .turn-text{font-size:38px;line-height:1.38;font-weight:600;overflow-wrap:anywhere}
  .snag{background:var(--warn-bg);border-color:#efd6aa;border-left-color:var(--warn)}.snag .turn-label{color:var(--warn)}
  .after{background:#edf2ff;border-color:#ccd8ff;border-left-color:var(--brand)}.after .turn-label{color:var(--brand)}
  .takeaway{background:var(--ink);border-color:var(--ink);color:#fff}.takeaway .turn-label{color:#ffd666}
  </style></head><body><main id="canvas"><h1 data-title>${esc(card.title)}</h1><div class="turn-body">${['before', 'snag', 'after', 'takeaway'].map(block).join('')}</div></main></body></html>`;
}

export async function measureTurnPage(page) {
  return page.evaluate(() => {
    const canvas = document.querySelector('#canvas');
    const cr = canvas.getBoundingClientRect();
    const textRect = (el) => {
      const range = document.createRange();
      range.selectNodeContents(el);
      const r = range.getBoundingClientRect();
      return { x: r.left - cr.left, y: r.top - cr.top, w: r.width, h: r.height };
    };
    const blocks = [...document.querySelectorAll('[data-turn-block]')].map((el) => {
      const text = el.querySelector('[data-body-text]');
      const r = el.getBoundingClientRect();
      const style = getComputedStyle(text);
      return {
        key: el.dataset.turnBlock,
        label: el.querySelector('.turn-label').textContent.trim(),
        text: text.textContent.trim(),
        rect: { x: r.left - cr.left, y: r.top - cr.top, w: r.width, h: r.height },
        textRect: textRect(text),
        font: parseFloat(style.fontSize),
        scrollW: text.scrollWidth,
        clientW: text.clientWidth,
        scrollH: text.scrollHeight,
        clientH: text.clientHeight,
      };
    });
    const title = document.querySelector('[data-title]');
    const c = document.createElement('canvas').getContext('2d');
    const font = getComputedStyle(document.body).fontFamily;
    c.font = `24px ${font}`;
    const han = c.measureText('记忆结构').width;
    const tofu = c.measureText('\uE000\uE001\uE002\uE003').width;
    return {
      canvas: { w: cr.width, h: cr.height },
      title: title.textContent.trim(),
      titleRect: textRect(title),
      blocks,
      pageText: document.body.innerText,
      fontOk: han > 0 && Math.abs(han - tofu) > 1,
    };
  });
}

export function judgeTurn(obs, card) {
  const findings = [];
  if (obs.blocks.length !== 4) findings.push(`画面应有四块，实测 ${obs.blocks.length} 块。`);
  for (const b of obs.blocks) {
    if (!b.text.trim()) findings.push(`「${b.label}」是空的。`);
    if (b.font < 20) findings.push(`「${b.label}」正文只有 ${b.font}px，小于 20px。`);
    if (b.font * 600 / WIDTH < 20) findings.push(`「${b.label}」缩到 600px 后小于 20px。`);
    if (b.scrollW > b.clientW + 1 || b.scrollH > b.clientH + 1) findings.push(`「${b.label}」文字溢出。`);
    if (b.textRect.x < b.rect.x - 1 || b.textRect.y < b.rect.y - 1 || b.textRect.x + b.textRect.w > b.rect.x + b.rect.w + 1 || b.textRect.y + b.textRect.h > b.rect.y + b.rect.h + 1)
      findings.push(`「${b.label}」文字超出色块。`);
  }
  if (obs.titleRect.x < -1 || obs.titleRect.y < -1 || obs.titleRect.x + obs.titleRect.w > WIDTH + 1 || obs.titleRect.h > 145) findings.push('标题超出预留区域。');
  if (!obs.fontOk) findings.push('中文字体没有正常加载。');
  if (/\b(?:units|relations|coverage)\b|差别｜|依据｜|归纳｜/i.test(obs.pageText)) findings.push('画面出现内部字段名。');
  if (/…|\.{3,}|。{3,}/.test(obs.pageText)) findings.push('画面出现省略号。');
  const chars = turnBodyChars(card);
  if (chars > 300) findings.push(`可见正文 ${chars} 字，超过 300 字。`);
  return { findings, metrics: { bodyChars: chars, bodyFontPx: obs.blocks.map((b) => b.font), fontAt600Px: obs.blocks.map((b) => Math.round(b.font * 600 / WIDTH * 10) / 10) } };
}

export async function renderTurnPng(card, outPath, { scale = 2, height = HEIGHT } = {}) {
  const browser = await launchBrowser();
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: WIDTH, height, deviceScaleFactor: scale });
    await page.setContent(buildTurnHtml(card, { height }), { waitUntil: 'load' });
    await page.evaluateHandle('document.fonts.ready');
    const obs = await measureTurnPage(page);
    const qa = judgeTurn(obs, card);
    if (qa.findings.length) throw new Error(`画面检查未通过：\n  ${qa.findings.join('\n  ')}`);
    await page.screenshot({ path: outPath, fullPage: false });
    return { widthPx: WIDTH * scale, heightPx: height * scale, qa };
  } finally {
    await closeBrowser(browser);
  }
}
