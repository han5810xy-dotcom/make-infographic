# AI 记得每一句，你只记住一套结构。

<img src="docs/assets/demo.gif?v=6" width="720" height="405" alt="选中一段对话，生成有证据的知识结构图" />

<img src="docs/assets/before-after-v2.png?v=1" width="720" height="450" alt="普通总结与有证据的知识结构总览对照" />

下载 [install.mjs](dist/install.mjs) 和 [make-infographic-2.1.1.zip](dist/make-infographic-2.1.1.zip)，放在同一个文件夹，然后运行：

```powershell
node install.mjs
```

**先立命题与关系，再决定它长成什么图。** 不是从文字直接跳像素，而是让每个结论、每条边、每个缺口都能回到原句。

## 三种入口

- **Qwen 浏览器扩展**：捕获当前可见会话与可见思考，统一成 Trace。
- **Qoder / DSH Skill**：选中一段对话，说「出图」。
- **粘贴／文件导入**：Markdown、纯文本、常见 JSON 导出。

同一段对话三条路都得到完整 Trace，再进入同一条结构工作流。

## 八步工作流

1. 完整浏览对话并保留轮次。
2. 分析重复度、追问度、纠正度、位置度。
3. 把内容拆成单条命题，每块附原句证据。
4. 只在命题之间建立有出处的关系。
5. 抽出 3~5 条主干；并列清单明确降级，不硬造骨架。
6. 由拓扑决定流程图、树状图、矩阵、知识关联图、循环图或森林图。
7. 检查来源、方向、层级、节点数、缺口与多图一致性。
8. 输出主图、分支细节图与知识总览。

## 一套语法，跨图一致

矩形是命题，圆是概念，菱形是判断／条件，六边形是例子，虚线框是推断／缺口；实线箭头是因果，虚线箭头是支持，双向箭头是对比，方括号是包含，折线是条件分支。蓝色给主干与纠正，橙色给冲突与例外，灰色给背景，红色给被推翻的判断。每张图都带原话／归纳／推断角标。

转折带保留为一种图种：**原以为 → 撞车 → 正解 → 一句带走**。

## 网站汇总

- [卡片库](https://chat-to-infographic-ue17fe4mvg7.qoder.zone/library.html)：主题、状态与关键词检索。
- [知识结构](https://chat-to-infographic-ue17fe4mvg7.qoder.zone/structure.html)：从总览进入主干，再沿证据进入细节。
- [个人档案](https://chat-to-infographic-ue17fe4mvg7.qoder.zone/profile.html)：出图历史、主题分布与时间线。
- [意境图](https://chat-to-infographic-ue17fe4mvg7.qoder.zone/ambient.html)：独立第二出口，只做装饰与纪念，与信息图分开存储。

## 从图到学习

每次出图都会同步到本机 `.knowledge/`。同一条命题在不同对话里保持同一个 `concept_id`，来源、证据和学习事件分别保存。

```bash
node scripts/learn.mjs due
node scripts/learn.mjs prompt <concept_id> --route explain
node scripts/learn.mjs answer <concept_id> --route explain --self-report without_looking --answer "自己的话"
node scripts/learn.mjs reveal <event_id>
node scripts/learn.mjs serve --port 5279
```

工作台先收回答，再揭示原命题与证据；提供概念图谱、自己的解释时间线和分路径档案。它不自动判分，不生成“掌握率”。学习包可完整导出并在另一台机器恢复。

## 验收数字

- 50 段私有真实对话：471 条命题、28 条经核对关系；最终输出 457 张图，HTML 降级 0。
- 关键结论覆盖率 91.3%；图种拓扑一致率 100%；多图编号与措辞错误 0。
- 24 组渲染宽度检查、16 组网页检查；安装包支持 CRC 校验、暂存安装与失败回滚。
- 学习回路覆盖跨会话身份、先提取后揭示、追加式作答、导出／恢复与并发写入。

这些是工程与结构验收数字，不等于学习效果已被证明。私有对话、学习答案与验收数据不进入公开发布包；真实 Qwen 登录态和人类专家复核仍需单独确认。

## 边界

- 命题超过 30 条就按主题拆分。
- 关系没有原句就删掉，并写进缺口；例子不能与主结论连成因果。
- 主图不超过 7 个节点，细节图不超过 12 个。
- 任何失败都走换视图、拆图或只出 HTML，禁止把校验失败当成交付。
- 使用本机 Edge 或 Chrome；不会自动下载 Chromium，不需要 API key。

## License

MIT。详见 [LICENSE](LICENSE)。
